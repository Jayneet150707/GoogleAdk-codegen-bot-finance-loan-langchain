import os
import numpy as np
from pymongo import MongoClient
from dotenv import load_dotenv
from tensorflow.keras.layers import TextVectorization
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, GlobalAveragePooling1D, Dense

load_dotenv()

def get_mongodb_client():
    """Connect to MongoDB Atlas."""
    connection_string = os.getenv("MONGODB_CONNECTION_STRING")
    client = MongoClient(connection_string)
    return client

def get_database(db_name="finance_db"):
    """Get a reference to the database."""
    client = get_mongodb_client()
    return client[db_name]

def get_collection(collection_name, db_name="finance_db"):
    """Get a reference to a collection."""
    db = get_database(db_name)
    return db[collection_name]

def create_text_embeddings(text_data, embedding_dim=128):
    """Create embeddings for text data."""
    # Create a text vectorization layer
    vectorize_layer = TextVectorization(
        max_tokens=10000,
        output_mode='int',
        output_sequence_length=250
    )
    vectorize_layer.adapt(text_data)
    
    # Create a simple embedding model
    model = Sequential([
        vectorize_layer,
        Embedding(10000, embedding_dim),
        GlobalAveragePooling1D(),
        Dense(embedding_dim, activation='relu')
    ])
    
    # Generate embeddings
    embeddings = model.predict(text_data)
    return embeddings

def store_embeddings_in_mongodb(collection, documents, embeddings):
    """Store documents with their embeddings in MongoDB."""
    for i, (doc, embedding) in enumerate(zip(documents, embeddings)):
        doc['embedding'] = embedding.tolist()
        collection.insert_one(doc)

